"""Pygame presentation, input, and main loop for The Hollow at Blackthorn.

Story rules live in story.py. Map positions are local to the world surface;
buttons use logical canvas coordinates. The canvas scales to fit the window,
and mouse positions are converted back to those same logical coordinates.
"""

import argparse
import os
import random
from pathlib import Path

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame

from story import CHARACTERS, MAX_THREAT, SCENES, GameState

WINDOW_WIDTH, WINDOW_HEIGHT = 1200, 820
INK = (219, 219, 205)
MUTED = (142, 155, 151)
GOLD = (213, 174, 105)
RED = (200, 99, 90)
BACKGROUND = (13, 20, 23)
WORLD_RECT = pygame.Rect(30, 130, 740, 460)
Color = tuple[int, int, int]
Point = tuple[float, float] | pygame.Vector2
UIAction = tuple[str, str | int | None]
TARGET_FPS = 60
MAX_FRAME_SECONDS = 0.05  # Cap movement after a stall or window drag.
PLAYER_SPEED = 190  # Map pixels per second, independent of frame rate.
PLAYER_RADIUS = 11
INTERACTION_RADIUS = 85
PLAYER_SPAWN = (355, 395)

# Furniture uses map-local coordinates, just like the scene interaction markers.
SCENE_OBSTACLES = {
    "road": ((170, 260, 180, 90),),
    "hall": ((105, 155, 110, 40), (500, 60, 145, 80)),
    "dining": ((245, 165, 225, 125),),
    "basement": ((90, 140, 150, 35), (495, 135, 125, 45)),
    "yard": ((95, 285, 110, 60),),
}


class Game:
    """Coordinate UI state, movement, rendering, and one story-state instance.

    ``mode`` is title, play, or ending. During play, a result modal, journal, or
    pause screen blocks decisions and movement. Drawing rebuilds the clickable
    button list for the current screen, including only the topmost overlay.
    """

    def __init__(self, screen: pygame.Surface) -> None:
        """Create rendering surfaces and begin on character selection."""
        self.screen = screen
        self.canvas = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        self.world = pygame.Surface(WORLD_RECT.size)
        self.fonts = {
            size: pygame.font.SysFont("consolas", size) for size in (14, 16, 18, 20, 24, 30, 40, 58)
        }
        self.running = True
        self.selected = "Evelyn"
        self.state = GameState(self.selected)
        self.mode = "title"
        self.modal = None
        self.journal = False
        self.paused = False
        self.player = pygame.Vector2(PLAYER_SPAWN)
        self.time = 0.0
        self.buttons = []
        self.rng = random.Random(350)  # Repeatable rain layout for visual checks.
        self.rain = [
            (self.rng.randrange(740), self.rng.randrange(460), self.rng.randrange(100, 260))
            for _ in range(80)
        ]

    def text(
        self,
        text: str,
        x: float,
        y: float,
        size: int = 18,
        color: Color = INK,
        surface: pygame.Surface | None = None,
    ) -> None:
        """Draw one line on the canvas, or on a supplied map surface."""
        surface = surface if surface is not None else self.canvas
        surface.blit(self.fonts[size].render(text, True, color), (x, y))

    def wrap(
        self,
        text: str,
        x: float,
        y: float,
        width: int,
        size: int = 18,
        color: Color = INK,
        line_height: int | None = None,
        surface: pygame.Surface | None = None,
    ) -> float:
        """Word-wrap paragraphs and return the y position below the final line."""
        line_height = line_height or size + 7
        for paragraph in text.split("\n"):
            line = ""
            for word in paragraph.split():
                candidate = f"{line} {word}".strip()
                if self.fonts[size].size(candidate)[0] > width and line:
                    self.text(line, x, y, size, color, surface)
                    y += line_height
                    line = word
                else:
                    line = candidate
            self.text(line, x, y, size, color, surface)
            y += line_height
        return y

    def mouse(self, point: Point) -> tuple[float, float]:
        """Map window coordinates to the fixed canvas, including letterboxing."""
        sw, sh = self.screen.get_size()
        scale = min(sw / WINDOW_WIDTH, sh / WINDOW_HEIGHT)
        return (
            (point[0] - (sw - WINDOW_WIDTH * scale) / 2) / scale,
            (point[1] - (sh - WINDOW_HEIGHT * scale) / 2) / scale,
        )

    def button(
        self,
        rect: tuple[int, int, int, int] | pygame.Rect,
        label: str,
        action: UIAction,
        enabled: bool = True,
        accent: bool = False,
    ) -> None:
        """Draw a button and register its hit area for the next input event."""
        rect = pygame.Rect(rect)
        hover = rect.collidepoint(self.mouse(pygame.mouse.get_pos()))
        color = (39, 52, 53) if hover and enabled else (23, 34, 38)
        pygame.draw.rect(self.canvas, color, rect, border_radius=5)
        pygame.draw.rect(self.canvas, GOLD if accent else (60, 76, 75), rect, 1, border_radius=5)
        self.text(
            label,
            rect.x + 14,
            rect.y + (rect.height - 18) // 2 - 2,
            18,
            INK if enabled else (94, 106, 106),
        )
        self.buttons.append((rect, action, enabled))

    def start(self) -> None:
        """Start a fresh run with the selected survivor and clear overlays."""
        self.state = GameState(self.selected)
        self.mode = "play"
        self.modal = None
        self.journal = self.paused = False
        self.player.update(PLAYER_SPAWN)

    def choose(self, index: int) -> None:
        """Convert a visible action index into a story decision and result modal."""
        if self.mode != "play" or self.modal or self.paused or self.journal or self.state.ending:
            return
        actions = SCENES[self.state.scene].actions
        if 0 <= index < len(actions):
            result = self.state.choose(actions[index].id)
            if result:
                self.modal = result

    def continue_result(self) -> None:
        """Dismiss a result before committing its ending or scene transition."""
        if self.modal is None:
            return
        self.modal = None
        if self.state.ending:
            self.mode = "ending"
        elif self.state.pending_scene:
            self.state.enter_pending()
            self.player.update(PLAYER_SPAWN)

    def handle(self, event: pygame.event.Event) -> None:
        """Route discrete keyboard and mouse events according to UI priority."""
        if event.type == pygame.QUIT:
            self.running = False
            return
        if event.type == pygame.KEYDOWN:
            key = event.key
            if self.mode == "title":
                if pygame.K_1 <= key <= pygame.K_4:
                    self.selected = list(CHARACTERS)[key - pygame.K_1]
                elif key == pygame.K_RETURN:
                    self.start()
                elif key == pygame.K_ESCAPE:
                    self.running = False
            elif self.mode == "ending":
                if key in (pygame.K_RETURN, pygame.K_r):
                    self.mode = "title"
                elif key == pygame.K_ESCAPE:
                    self.running = False
            elif self.modal:
                if key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
                    self.continue_result()
            elif key == pygame.K_j:
                self.journal = not self.journal
            elif key in (pygame.K_ESCAPE, pygame.K_p):
                if self.journal:
                    self.journal = False
                else:
                    self.paused = not self.paused
            elif not self.paused and not self.journal:
                if pygame.K_1 <= key <= pygame.K_4:
                    self.choose(key - pygame.K_1)
                elif key == pygame.K_e:
                    index = self.nearest()
                    if index is not None:
                        self.choose(index)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            point = self.mouse(event.pos)
            for rect, action, enabled in reversed(self.buttons):
                if rect.collidepoint(point) and enabled:
                    self.activate(action)
                    break

    def activate(self, action: UIAction) -> None:
        """Apply a named UI command stored with a clicked button."""
        kind, value = action
        if kind == "select" and isinstance(value, str):
            self.selected = value
        elif kind == "start":
            self.start()
        elif kind == "choice" and isinstance(value, int):
            self.choose(value)
        elif kind == "continue":
            self.continue_result()
        elif kind == "journal":
            self.journal = not self.journal
        elif kind == "resume":
            self.paused = False
        elif kind == "title":
            self.mode = "title"
            self.modal = None
            self.journal = self.paused = False
        elif kind == "quit":
            self.running = False

    def nearest(self) -> int | None:
        """Return the closest unused action index within interaction range."""
        candidates = [
            (self.player.distance_to(a.position), i)
            for i, a in enumerate(SCENES[self.state.scene].actions)
            if a.id not in self.state.used
        ]
        if candidates:
            distance, index = min(candidates)
            if distance < INTERACTION_RADIUS:
                return index
        return None

    def blockers(self) -> list[pygame.Rect]:
        """Return solid furniture rectangles for the active scene."""
        return [pygame.Rect(bounds) for bounds in SCENE_OBSTACLES[self.state.scene]]

    def update(self, dt: float) -> None:
        """Advance rain animation and move the player using elapsed seconds."""
        self.time += dt
        if self.mode != "play" or self.modal or self.journal or self.paused:
            return
        keys = pygame.key.get_pressed()
        direction = pygame.Vector2(
            int(keys[pygame.K_d] or keys[pygame.K_RIGHT])
            - int(keys[pygame.K_a] or keys[pygame.K_LEFT]),
            int(keys[pygame.K_s] or keys[pygame.K_DOWN])
            - int(keys[pygame.K_w] or keys[pygame.K_UP]),
        )
        if direction.length_squared():
            direction = direction.normalize()
            step = direction * PLAYER_SPEED * dt
            obstacles = self.blockers()
            # Resolve each axis independently so the player slides along furniture.
            for axis in (0, 1):
                test = self.player.copy()
                test[axis] += step[axis]
                body = pygame.Rect(
                    test.x - PLAYER_RADIUS,
                    test.y - PLAYER_RADIUS,
                    PLAYER_RADIUS * 2,
                    PLAYER_RADIUS * 2,
                )
                if not any(body.colliderect(rect) for rect in obstacles):
                    self.player = test
            self.player.x = max(22, min(718, self.player.x))
            self.player.y = max(26, min(432, self.player.y))

    def draw_world(self) -> None:
        """Draw scene furniture, lighting, interaction markers, and characters."""
        world_surface = self.world
        scene = self.state.scene
        outside = scene in ("road", "yard")
        world_surface.fill((25, 34, 33) if outside else (37, 35, 32))
        if outside:
            for i in range(90):
                x, y = (i * 137 + 19) % 740, (i * 73 + 31) % 460
                pygame.draw.line(world_surface, (35, 45, 39), (x, y), (x + 8, y - 9), 2)
        else:
            for y in range(0, 460, 36):
                pygame.draw.line(world_surface, (47, 43, 38), (0, y), (740, y))
                for x in range((y // 36 % 2) * 70, 740, 140):
                    pygame.draw.line(world_surface, (47, 43, 38), (x, y), (x, y + 36))
            pygame.draw.rect(world_surface, (69, 63, 54), (6, 6, 728, 448), 10)
        if scene == "road":
            pygame.draw.polygon(
                world_surface, (43, 47, 44), [(115, 460), (370, 460), (640, 100), (520, 95)]
            )
            for x in (26, 76, 675, 715):
                pygame.draw.rect(world_surface, (15, 24, 23), (x, 0, 14, 455))
                pygame.draw.circle(world_surface, (18, 29, 26), (x + 7, 50), 57)
            pygame.draw.rect(world_surface, (76, 89, 85), (170, 260, 180, 90), border_radius=20)
            pygame.draw.rect(world_surface, (23, 41, 45), (220, 269, 70, 72), border_radius=5)
            pygame.draw.polygon(
                world_surface, (76, 74, 51), [(345, 275), (510, 205), (510, 390), (345, 335)]
            )
            self.text("BLACKTHORN", 516, 65, 18, MUTED, world_surface)
        elif scene == "hall":
            pygame.draw.rect(world_surface, (70, 43, 42), (300, 40, 110, 410))
            for y in range(60, 150, 15):
                pygame.draw.rect(world_surface, (100, 89, 72), (500, y, 145, 10))
            pygame.draw.rect(world_surface, (76, 60, 46), (105, 155, 110, 40))
            pygame.draw.rect(world_surface, (106, 83, 56), (117, 45, 85, 85), 5)
            pygame.draw.line(world_surface, (119, 66, 57), (126, 55), (188, 116), 5)
            pygame.draw.circle(world_surface, (131, 115, 76), (355, 165), 40, 3)
            for x in (330, 355, 380):
                pygame.draw.circle(world_surface, GOLD, (x, 165), 4)
        elif scene == "dining":
            pygame.draw.rect(world_surface, (90, 68, 49), (245, 165, 225, 125), border_radius=12)
            for x in range(265, 465, 36):
                for y in (182, 268):
                    pygame.draw.circle(world_surface, (160, 152, 125), (x, y), 10, 2)
            for x in (280, 350, 420):
                pygame.draw.circle(world_surface, GOLD, (x, 226), 3)
            pygame.draw.rect(world_surface, (54, 73, 75), (555, 50, 80, 85))
            pygame.draw.line(world_surface, (105, 97, 77), (595, 50), (595, 135), 7)
            pygame.draw.rect(world_surface, (22, 25, 24), (95, 50, 105, 85))
        elif scene == "basement":
            for x in (30, 55, 675):
                pygame.draw.line(world_surface, (82, 82, 68), (x, 0), (x, 460), 7)
            pygame.draw.rect(world_surface, (88, 70, 50), (90, 140, 150, 35))
            pygame.draw.rect(world_surface, (81, 89, 82), (495, 135, 125, 45))
            for i, color in enumerate((RED, GOLD, MUTED)):
                pygame.draw.line(world_surface, color, (520 + i * 25, 142), (520 + i * 25, 173), 3)
            pygame.draw.rect(world_surface, (9, 16, 19), (560, 390, 100, 70))
        else:
            for x in range(500, 680, 18):
                pygame.draw.line(world_surface, (107, 117, 109), (x, 30), (x, 150), 5)
            for y in (55, 120):
                pygame.draw.line(world_surface, (107, 117, 109), (500, y), (675, y), 5)
            for x in (120, 175):
                pygame.draw.circle(world_surface, (67, 66, 53), (x, 315), 27)
                pygame.draw.circle(world_surface, (110, 100, 73), (x, 315), 27, 2)
            pygame.draw.line(world_surface, (149, 124, 81), (350, 0), (350, 162), 4)
            self.person(world_surface, (590, 390), (29, 25, 27), True)
        # A dark overlay pools around the player; a flashlight widens visibility.
        shade = pygame.Surface(WORLD_RECT.size, pygame.SRCALPHA)
        shade.fill((0, 4, 10, 125))
        radius = 225 if "Flashlight" in self.state.inventory else 145
        for r in range(radius, 15, -10):
            alpha = int(115 * (1 - r / radius))
            pygame.draw.circle(shade, (0, 4, 9, 110 - alpha), self.player, r)
        world_surface.blit(shade, (0, 0))
        near = self.nearest()
        for i, action in enumerate(SCENES[scene].actions):
            done = action.id in self.state.used
            point = action.position
            color = (72, 84, 80) if done else GOLD if i == near else (145, 166, 153)
            pygame.draw.circle(world_surface, (17, 26, 29), point, 19)
            pygame.draw.circle(world_surface, color, point, 19, 2)
            self.text(
                "-" if done else str(i + 1), point[0] - 6, point[1] - 10, 18, color, world_surface
            )
        self.person(world_surface, self.player, CHARACTERS[self.state.character].color)
        if outside:
            for x, y, speed in self.rain:
                yy = int((y + self.time * speed) % 480) - 10
                xx = int((x - self.time * 40) % 760)
                pygame.draw.line(world_surface, (83, 103, 110), (xx, yy), (xx - 4, yy + 12))
        self.canvas.blit(world_surface, WORLD_RECT)
        pygame.draw.rect(self.canvas, (66, 79, 76), WORLD_RECT, 1)

    @staticmethod
    def person(surface: pygame.Surface, point: Point, color: Color, killer: bool = False) -> None:
        """Draw a simple top-down survivor or masked killer sprite."""
        x, y = int(point[0]), int(point[1])
        pygame.draw.ellipse(surface, (9, 15, 17), (x - 17, y + 9, 34, 13))
        pygame.draw.circle(surface, color, (x, y), 15)
        pygame.draw.circle(surface, (194, 192, 166) if killer else (181, 163, 134), (x, y - 7), 9)
        if killer:
            for dx in (-4, 4):
                pygame.draw.circle(surface, (20, 24, 24), (x + dx, y - 8), 2)
            pygame.draw.line(surface, (150, 160, 152), (x + 17, y + 3), (x + 27, y + 19), 4)

    def draw_title(self) -> None:
        """Draw the four character cards and the start button."""
        self.text("A SHORT SURVIVAL HORROR PROTOTYPE", 62, 42, 18, GOLD)
        self.text("THE HOLLOW", 58, 83, 58)
        self.text("AT BLACKTHORN", 62, 151, 30, MUTED)
        self.wrap(
            "Four friends. A stalled car. A house that is listening. Choose who you follow through the night.",
            65,
            210,
            1000,
            20,
        )
        for i, (name, character) in enumerate(CHARACTERS.items()):
            color = character.color
            rect = pygame.Rect(62 + i * 280, 308, 260, 297)
            pygame.draw.rect(self.canvas, (23, 34, 38), rect, border_radius=8)
            pygame.draw.rect(
                self.canvas,
                color if name == self.selected else (55, 68, 69),
                rect,
                2,
                border_radius=8,
            )
            self.person(self.canvas, (rect.x + 37, 347), color)
            self.text(f"{i + 1}  {name}", rect.x + 20, 382, 24, color)
            self.text(character.role, rect.x + 20, 420, 16, GOLD)
            y = self.wrap(character.biography, rect.x + 20, 453, 220, 16)
            self.wrap(character.traits, rect.x + 20, y + 10, 220, 14, MUTED)
            self.buttons.append((rect, ("select", name), True))
        self.button((62, 642, 330, 55), "ENTER THE ESTATE   [Enter]", ("start", None), accent=True)
        self.wrap(
            "Walk: WASD / arrows   Interact: E   Choices: 1-4 or mouse\nJournal: J   Pause: Esc / P   No real-time countdown.",
            62,
            723,
            1090,
            16,
            MUTED,
        )

    def draw_play(self) -> None:
        """Draw the map, scene text, inventory, threat meter, and action list."""
        state = self.state
        scene = SCENES[state.scene]
        self.text("THE HOLLOW / BLACKTHORN", 30, 23, 18, GOLD)
        self.text(scene.title, 30, 60, 30)
        self.text(scene.subtitle, 32, 101, 16, MUTED)
        self.text(
            f"{state.character.upper()}  /  {CHARACTERS[state.character].role}", 800, 29, 16, MUTED
        )
        self.text(f"DECISIONS  {state.decisions} / {scene.decisions}", 800, 63, 24, GOLD)
        self.text("THREAT", 800, 103, 14, MUTED)
        for i in range(MAX_THREAT):
            pygame.draw.rect(
                self.canvas,
                RED if i < state.threat else (43, 53, 54),
                (875 + i * 45, 104, 34, 9),
                border_radius=2,
            )
        self.draw_world()
        self.text("THE SCENE", 800, 142, 16, GOLD)
        y = self.wrap(scene.description, 800, 175, 367, 18)
        self.text("INVENTORY", 800, y + 18, 16, GOLD)
        y = self.wrap(
            " / ".join(sorted(state.inventory)) or "Empty pockets", 800, y + 48, 365, 16, MUTED
        )
        if state.gate_override_disabled:
            self.text("Gate override: disabled", 800, y + 12, 16, GOLD)
        self.button(
            (800, 717, 368, 40), f"JOURNAL  [{len(state.clues)} clues]   J", ("journal", None)
        )
        self.text("WASD move  /  E interact", 800, 777, 14, MUTED)
        near = self.nearest()
        self.text("CHOOSE AN ACTION  /  1-4 OR CLICK", 30, 603, 14, GOLD)
        for i, action in enumerate(scene.actions):
            enabled = action.id not in state.used
            self.button(
                (30, 630 + 40 * i, 740, 34),
                f"{i + 1}  {action.label}" + ("  [done]" if not enabled else ""),
                ("choice", i),
                enabled,
                i == near,
            )
        if near is not None:
            pygame.draw.rect(
                self.canvas,
                (17, 26, 29),
                (WORLD_RECT.x + 10, WORLD_RECT.y + 10, 720, 58),
                border_radius=4,
            )
            self.wrap(
                "[E] " + scene.actions[near].hint,
                WORLD_RECT.x + 23,
                WORLD_RECT.y + 18,
                690,
                16,
                GOLD,
            )

    def overlay(self, title: str, text: str, button_label: str, action: UIAction) -> None:
        """Dim the play screen and replace its hit areas with one modal button."""
        veil = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        veil.fill((2, 8, 12, 220))
        self.canvas.blit(veil, (0, 0))
        rect = pygame.Rect(195, 205, 810, 410)
        pygame.draw.rect(self.canvas, (22, 32, 35), rect, border_radius=8)
        pygame.draw.rect(self.canvas, (107, 101, 77), rect, 1, border_radius=8)
        self.text(title, 230, 236, 24, GOLD)
        self.wrap(text, 230, 286, 730, 20, line_height=29)
        self.buttons.clear()
        self.button((230, 538, 740, 46), button_label, action, accent=True)

    def draw_journal(self) -> None:
        """Display learned clues without spending a story decision."""
        veil = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        veil.fill((2, 8, 12, 235))
        self.canvas.blit(veil, (0, 0))
        self.text("FIELD NOTES", 150, 75, 40, GOLD)
        y = 143
        if not self.state.clues:
            y = self.wrap(
                "No clues yet. Listen to the descriptions before committing a decision.",
                150,
                y,
                880,
                20,
            )
        for name, clue in self.state.clues.items():
            self.text(name.upper(), 150, y, 16, GOLD)
            y = self.wrap(clue, 150, y + 28, 880, 18) + 17
        self.buttons.clear()
        self.button((150, 730, 880, 45), "RETURN TO THE HOUSE   [J / Esc]", ("journal", None))

    def draw_ending(self) -> None:
        """Display the final outcome and offer replay or quit."""
        won = self.state.survived
        self.text(
            "DAWN" if won else "THE HOUSE KEEPS ANOTHER SECRET", 95, 100, 20, GOLD if won else RED
        )
        self.wrap(self.state.ending, 90, 175, 1020, 40)
        self.wrap(self.state.ending_text, 95, 285, 1000, 24, line_height=36)
        self.text(
            f"{self.state.character}  /  {self.state.actions_taken} decisions  /  {len(self.state.clues)} clues",
            95,
            500,
            18,
            MUTED,
        )
        self.button(
            (95, 570, 480, 55), "CHOOSE ANOTHER SURVIVOR   [Enter]", ("title", None), accent=True
        )
        self.button((95, 648, 220, 44), "QUIT", ("quit", None))
        self.text(
            "Different strengths, evidence, and choices lead to different endings.",
            95,
            750,
            16,
            MUTED,
        )

    def draw(self) -> None:
        """Render the active screen and scale it to the current window size."""
        self.canvas.fill(BACKGROUND)
        self.buttons.clear()
        if self.mode == "title":
            self.draw_title()
        elif self.mode == "ending":
            self.draw_ending()
        else:
            self.draw_play()
            if self.modal:
                self.overlay(
                    "THE CONSEQUENCE", self.modal, "CONTINUE   [Enter / Space]", ("continue", None)
                )
            elif self.journal:
                self.draw_journal()
            elif self.paused:
                self.overlay(
                    "PAUSED",
                    "Every attempted action costs a decision, including a failed attempt. Walking and reading your journal are free. Used actions cannot be repeated.\n\nThe killer advances through decisions, not elapsed time.",
                    "RESUME   [Esc / P]",
                    ("resume", None),
                )
                self.button((730, 634, 275, 42), "RETURN TO TITLE", ("title", None))
        sw, sh = self.screen.get_size()
        scale = min(sw / WINDOW_WIDTH, sh / WINDOW_HEIGHT)
        size = (max(1, int(WINDOW_WIDTH * scale)), max(1, int(WINDOW_HEIGHT * scale)))
        self.screen.fill((5, 9, 12))
        self.screen.blit(
            pygame.transform.smoothscale(self.canvas, size),
            ((sw - size[0]) // 2, (sh - size[1]) // 2),
        )
        pygame.display.flip()


def smoke_test(game: Game, screenshot: Path | None) -> None:
    """Exercise the actual renderer and input handlers without opening a window."""
    game.draw()
    game.handle(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN))
    assert game.mode == "play"
    game.handle(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_1))
    assert "Flashlight" in game.state.inventory and game.modal
    game.draw()
    game.handle(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN))
    for scene in SCENES:
        game.state.scene = scene
        game.state.decisions = SCENES[scene].decisions
        game.state.used.clear()
        game.draw()
    game.journal = True
    game.draw()
    game.journal = False
    game.paused = True
    game.draw()
    game.paused = False
    game.state.scene = "hall"
    game.state.decisions = 2
    game.state.used.clear()
    game.state.clues["stairs"] = "He hears the stairs. Do not use them when the house is quiet."
    game.draw()
    if screenshot:
        pygame.image.save(game.canvas, screenshot)
    game.state.finish("THE TRUTH GETS OUT", "You escaped with the evidence.")
    game.mode = "ending"
    game.draw()
    print(
        "Smoke test passed: menu, keyboard actions, results, all five scenes, journal, pause, ending."
    )


def main() -> None:
    """Parse command-line options, initialize Pygame, and run at a capped FPS."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke-test", action="store_true")
    parser.add_argument("--screenshot", type=Path)
    args = parser.parse_args()
    if args.smoke_test:
        os.environ["SDL_VIDEODRIVER"] = "dummy"
        os.environ["SDL_AUDIODRIVER"] = "dummy"
    try:
        pygame.display.init()
        pygame.font.init()
        screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.RESIZABLE)
        pygame.display.set_caption("The Hollow at Blackthorn | CIS350 Prototype")
        game = Game(screen)
        if args.smoke_test:
            smoke_test(game, args.screenshot)
        else:
            clock = pygame.time.Clock()
            game.draw()
            while game.running:
                dt = min(clock.tick(TARGET_FPS) / 1000, MAX_FRAME_SECONDS)
                for event in pygame.event.get():
                    game.handle(event)
                    # Refresh hit areas after each event so two queued clicks
                    # cannot activate controls from different screens.
                    if game.running and event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                        game.draw()
                game.update(dt)
                game.draw()
    finally:
        # Release the display even if initialization or an unexpected rule fails.
        pygame.quit()


if __name__ == "__main__":
    main()
