# The Hollow at Blackthorn

A small playable 2D Pygame prototype for CIS350, based on the supplied
[horror game design conversation](https://chatgpt.com/share/6ad5297a-3800-83ea-8243-b42b61dc44c2).

Choose one of four survivors, explore five scenes, collect evidence, and escape
the masked killer—or turn the house's trap against him. A run takes about 5–10
minutes. Everything is drawn with Pygame shapes; no asset downloads are needed.

## Run

Requires Python 3.10 or newer. From this folder:

```powershell
python -m pip install -r requirements.txt
python main.py
```

On Windows you can also double-click **Play.bat** after installing the requirement.
The launcher keeps errors visible if Python or Pygame is missing.

## Controls

| Input | Action |
| --- | --- |
| 1–4 on the title screen / click a character | Select survivor |
| Enter / click Enter the Estate | Start |
| WASD / arrow keys | Walk around the 2D scene |
| E near a numbered marker | Interact |
| 1–4 / click an action | Choose an action from anywhere in the room |
| Enter / Space / click Continue | Dismiss an outcome |
| J | Open/close clue journal |
| Esc / P | Pause/resume; Esc also closes the journal |
| Enter / R after an ending | Return to character selection |
| Window close button | Quit |

Every attempted action costs a decision, including failed attempts. Walking,
reading the scene, and checking the journal cost nothing. Leaving a scene ends
your time there. When decisions run out, footsteps force you onward and threat
increases. At six threat, the killer finds you. There is no real-time countdown.
An outcome stays on screen until you dismiss it; it will never skip unread text.

Marcus can force obstacles; Evelyn discovers a hidden clue; Noah can bypass the
gate relay without its diagram; Sofia can move safely through darkness. Everyone
has a route to escape and a route to use the trap. Inventory and clues last for
the current run. Repeated searches are disabled.

## Prototype scope

Includes character selection, a movable top-down character, furniture collision,
rain and darkness, limited scene decisions, inventory, clue journal, a threat
meter, character-dependent outcomes, four survival endings and fatal branches.
It deliberately uses decision-based danger rather than a pursuing enemy AI.
There is no save system, audio, combat system, or full campaign.

## Checks

```powershell
python -m unittest -v
python main.py --smoke-test --screenshot preview.png
```

The first command checks story branches and state transitions. The second uses
SDL's dummy display to exercise every scene, menu, overlay, and ending renderer.

`story.py` holds the characters, scenes, and rules; `main.py` handles Pygame
rendering and input. [DESIGN.md](DESIGN.md) explains the data model, decision flow,
UI coordinates, design choices, limitations, and how to extend the prototype.

## Development setup

For an isolated environment, run these commands from the project folder. Using
the environment's Python directly avoids needing to activate it in PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe main.py
```

The Windows launcher prefers `.venv` when it exists, otherwise it uses `python`.
Pygame is the only runtime dependency. Ruff is an optional development tool.

After installing development dependencies:

```powershell
.\.venv\Scripts\ruff.exe check .
.\.venv\Scripts\ruff.exe format --check .
.\.venv\Scripts\python.exe -m unittest -v
.\.venv\Scripts\python.exe main.py --smoke-test --screenshot preview.png
```

Use `ruff format .` to apply formatting. The shared configuration targets Python
3.10 and uses a 100-character formatting width. Tests cover both story rules and
headless UI input; manual playtesting is still useful for layout and story flow.

## Optional walkthrough (spoilers)

For an evidence escape with any character: take the flashlight, inspect the
tracks, enter the estate; read the note, inspect the chandelier; search the
pantry, read the scratches, take the service stairs; read the maintenance log,
bypass the override, take the passage; open the gate.

For the trap ending, follow the same path and cut the service rope in the yard.
Marcus can also escape directly through the dining-room window.
